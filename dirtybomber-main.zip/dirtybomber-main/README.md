# DirtyBomber
<h2>Украинский СМС бомбер с открытым кодом от украинских разработчиков.</h2>

## Потребности
Программа тестировалась на версии Python 3.X, потому рекомендуем ее для запуска.
# Установка
1. Скачивание репозитория.
Или вручную через WeB интерфейс GitHub.
Или через консольную команду **git clone https://github.com/AvenCores/dirtybomber**
2. Установление зависимостей: **pip install -r requirements.txt**
3. Файл запуска start.py, для запуска через консоль **python start.py**

---
- Телеграм канал: https://t.me/avencoresyt
- Ютуб канал: https://youtube.com/@avencores
- Дзен канал: https://dzen.ru/avencores
- Рутуб канал: https://rutube.ru/channel/34072414
- Группа в ВК: https://vk.com/avencoresvk

## ⬇️Поддержать автора⬇️
- ✅SBER: 2202 2050 7215 4401
- ✅VTB: 2200 2404 1001 8580
